package org.swe.android.activities;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.os.AsyncTask;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import org.swe.android.R;
import org.swe.android.datasource.SurveyDataSource;
import org.swe.android.datasource.User;
import org.swe.android.helpers.NetworkHelper;

/**
 * Created by YongjiLi on 11/17/15.
 */
public class AdminSignUpActivity extends Activity {

    Button buttonSignUp;
    Button buttonCancel;
    private ConnectivityManager mConnectivityManager;
    private String mUserId,mEmail,mPassword,mPasswordAgain;
    private EditText etUserId,etEmail,etPassword, etPasswordAgain;
    User newUser = new User();

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //Adjust the soft-keyboard automatically,put this line before setContentView
        getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_PAN);

        setContentView(R.layout.admin_sign_up);

        etUserId = (EditText) findViewById(R.id.et_sign_up_username);
        etEmail = (EditText) findViewById(R.id.et_sign_up_email);
        etPassword = (EditText) findViewById(R.id.et_sign_up_password);
        etPasswordAgain = (EditText) findViewById(R.id.et_sign_up_password_again);

        // Set up the Connectivity Manager
        mConnectivityManager = (ConnectivityManager) getApplicationContext().
                getSystemService(Context.CONNECTIVITY_SERVICE);

        addListenerOnButtonCancel();
        addListenerOnButtonSignUp();
    }

    public void addListenerOnButtonSignUp() {

        buttonSignUp = (Button) findViewById(R.id.button_Sign_Up);
        buttonSignUp.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View arg0) {
                if (!NetworkHelper.hasInternetConnection(mConnectivityManager)) {
                    Toast.makeText(getApplicationContext(),
                            R.string.toast_internet_connection_required,
                            Toast.LENGTH_LONG).show();
                } else {
                    // If we have username and password, run the AsyncTask to get the Username from the database tabel SWE_user
                    inputCheck();
                    if (mUserId != null && mEmail != null &&
                            mPassword != null && mPasswordAgain != null &&
                            mPassword.equals(mPasswordAgain) &&
                            isValidEmail(mEmail)) {
                        new userNameCheckTask().execute(mUserId);
                    }
                }
            }
        });
    }

    // Get the UserId that the user has entered ID= the string from user input
    private void inputCheck() {

        // If the user has not entered a value, show a toast to let them know to enter
        // your Username, otherwise, set the username to the value they have entered
        if (TextUtils.getTrimmedLength(etUserId.getText()) == 0) {
            Toast.makeText(getApplicationContext(),
                    R.string.toast_please_enter_user_name,
                    Toast.LENGTH_SHORT).show();
            mUserId = null;
        }
        else {
            mUserId = etUserId.getText().toString().trim();
        }

        // If the user has not entered a value, show a toast to let them know to enter
        // password, otherwise, set the password to the value they have entered
        if (TextUtils.getTrimmedLength(etEmail.getText()) == 0) {
            Toast.makeText(getApplicationContext(),
                    R.string.toast_please_enter_email,
                    Toast.LENGTH_SHORT).show();
            mEmail = null;
        }
        else {
            mEmail = etEmail.getText().toString().trim();
            if(!isValidEmail(mEmail)){
                Toast.makeText(getApplicationContext(),
                        R.string.toast_please_check_email,
                        Toast.LENGTH_SHORT).show();
            }
        }

        if (TextUtils.getTrimmedLength(etPassword.getText()) == 0) {
            Toast.makeText(getApplicationContext(),
                    R.string.toast_please_enter_password,
                    Toast.LENGTH_SHORT).show();
            mPassword = null;
        }
        else {
            mPassword = etPassword.getText().toString().trim();
        }

        if (TextUtils.getTrimmedLength(etPasswordAgain.getText()) == 0) {
            Toast.makeText(getApplicationContext(),
                    R.string.toast_please_enter_password_again,
                    Toast.LENGTH_SHORT).show();
            mPasswordAgain = null;
        }
        else {
            mPasswordAgain = etPasswordAgain.getText().toString().trim();
            if(!mPasswordAgain.equals(mPassword)){
                Toast.makeText(getApplicationContext(),
                        R.string.toast_password__does_not_match,
                        Toast.LENGTH_SHORT).show();
            }
        }
    }

    public static boolean isValidEmail(CharSequence target) {
        return !TextUtils.isEmpty(target) && android.util.Patterns.EMAIL_ADDRESS.matcher(target).matches();
    }

    private class userNameCheckTask extends AsyncTask<String, Integer, User> {
        @Override
        protected User doInBackground(String... params) {
            // Read the user from the database that has the given username and password
            return SurveyDataSource.getUserInfo(SurveyDataSource.DATA_SOURCE, getApplicationContext(),
                    params[0]); // Survey ID
        }

        @Override
        protected void onPostExecute(User user) {
            super.onPostExecute(user);

            // If a user info was found, display a toast to let the user know this Id has been used
            // and let the user to retry entering username and password.
            if (user == null) {
                newUser.setPassword(mPassword);
                newUser.setUserId(mUserId);
                newUser.setEmail(mEmail);

                new SignUpTask().execute(newUser);

            } else {
                Toast.makeText(getApplicationContext(),
                        R.string.toast_userid_is_already_existed,
                        Toast.LENGTH_LONG).show();
            }
        }
    }

    private class SignUpTask extends AsyncTask<User, Integer, Boolean> {

        @Override
        protected Boolean doInBackground(User... user) {
            return SurveyDataSource.insertUser(SurveyDataSource.DATA_SOURCE,
                    getApplicationContext(), newUser);
        }

        @Override
        protected void onPostExecute(Boolean aBoolean) {
            if (aBoolean) {
                Toast.makeText(getApplicationContext(), getString(R.string.toast_sign_up_success),
                        Toast.LENGTH_LONG).show();

                Intent intent = new Intent(AdminSignUpActivity.this, AdminLoginActivity.class);
                intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(intent);

            } else {
                Toast.makeText(getApplicationContext(), getString(R.string.toast_error_saving_user),
                        Toast.LENGTH_LONG).show();
            }
        }
    }

    public void addListenerOnButtonCancel() {

        final Context context = this;
        buttonCancel = (Button) findViewById(R.id.button_Sign_Up_cancel);
        buttonCancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View arg0) {

                Intent intent = new Intent(context, AdminLoginActivity.class);
                startActivity(intent);
            }
        });
    }
}
