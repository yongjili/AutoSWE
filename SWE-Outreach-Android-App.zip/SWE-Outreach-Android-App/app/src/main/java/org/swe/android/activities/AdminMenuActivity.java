package org.swe.android.activities;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.os.AsyncTask;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import org.swe.android.R;
import org.swe.android.datasource.SurveyDataSource;
import org.swe.android.datasource.SurveyParcelable;
import org.swe.android.datasource.SurveyResultsQuantified;
import org.swe.android.helpers.NetworkHelper;

/**
 * Created by YongjiLi on 9/23/15.
 */
public class AdminMenuActivity extends Activity {

    Button buttonDone;
    private ConnectivityManager mConnectivityManager;
    private String mSurveyId;
    private String mSurveyTitle = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //Adjust the soft-keyboard automatically,put this line before setContentView
        getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_PAN);
        setContentView(R.layout.admin_menu);
        final Button createSurveyButton = (Button) findViewById(R.id.button_create_survey);
        mConnectivityManager = (ConnectivityManager) getApplicationContext().
                getSystemService(Context.CONNECTIVITY_SERVICE);

        createSurveyButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // If the user does not have an internet connection, let them know that one
                // is required to look up the survey
                if (!NetworkHelper.hasInternetConnection(mConnectivityManager)) {
                    Toast.makeText(getApplicationContext(),
                            R.string.toast_internet_connection_required,
                            Toast.LENGTH_LONG).show();
                } else {
                    // Set the survey ID based on what the user has entered
                    setSurveyId();
                    // If we have a survey ID, run the AsyncTask to check the survey from the database
                    if (mSurveyId != null) {
                        new CreateSurveyCheckTask().execute(mSurveyId);
                    }

                }
            }
        });
        // Set up Take Survey button
        final Button takeSurveyButton = (Button) findViewById(R.id.button_take_survey_admin);

        // Set up the Connectivity Manager
        mConnectivityManager = (ConnectivityManager) getApplicationContext().
                getSystemService(Context.CONNECTIVITY_SERVICE);

        takeSurveyButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // If the user does not have an internet connection, let them know that one
                // is required to look up the survey
                if (!NetworkHelper.hasInternetConnection(mConnectivityManager)) {
                    Toast.makeText(getApplicationContext(),
                            R.string.toast_internet_connection_required,
                            Toast.LENGTH_LONG).show();
                } else {
                    // Set the survey ID based on what the user has entered
                    setSurveyId();

                    // If we have a survey ID, run the AsyncTask to get the survey from the database
                    if (mSurveyId != null) {
                        new GetSurveyTask().execute(mSurveyId);
                    }
                }
            }
        });

        // Set up View Results button
        final Button viewResultsButton = (Button) findViewById(R.id.button_view_results_admin);

        viewResultsButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // If the user does not have an internet connection, let them know that one
                // is required
                if (!NetworkHelper.hasInternetConnection(mConnectivityManager)) {
                    Toast.makeText(getApplicationContext(),
                            R.string.toast_internet_connection_required,
                            Toast.LENGTH_LONG).show();
                } else {
                    // Set the survey ID based on what the user has entered
                    setSurveyId();

                    // If we have a survey ID, run the AsyncTask to get the survey results from the database
                    if (mSurveyId != null) {
                        new GetSurveyResultsTask().execute(mSurveyId);
                    }
                }
            }
        });

        addListenerOnButtonDone();
    }

    // Get the survey ID that the user has entered ID= the string from user input + date + time
    private void setSurveyId() {
        EditText editText = (EditText) findViewById(R.id.editTextAdmin);

        // If the user has not entered a value, show a toast to let them know to enter
        // a survey ID, otherwise, set the survey ID to the value they have entered
        if (TextUtils.getTrimmedLength(editText.getText()) == 0) {
            Toast.makeText(getApplicationContext(),
                    R.string.toast_please_enter_survey_id,
                    Toast.LENGTH_SHORT).show();
            mSurveyId = null;
        }
        else {
            mSurveyId = editText.getText().toString().trim();
        }
    }

    protected void addListenerOnButtonDone() {

        final Context context = this;

        buttonDone = (Button) findViewById(R.id.button_done);

        buttonDone.setOnClickListener(new OnClickListener() {

            @Override
            public void onClick(View arg0) {

                Intent intent = new Intent(context, MainActivity.class);
                startActivity(intent);
            }

        });
    }

    private class CreateSurveyCheckTask extends AsyncTask<String, Integer, SurveyParcelable> {
       @Override
       protected SurveyParcelable  doInBackground(String... params) {
            // Read the survey from the database that has the given survey ID
            return SurveyDataSource.getSurvey(SurveyDataSource.DATA_SOURCE,getApplicationContext(),
                    params[0]); // Survey ID

        }

       @Override
        protected void onPostExecute(SurveyParcelable survey) {
            super.onPostExecute(survey);

           // If a survey was found, display a toast to let the user know this Id has been used
           // and let the user to retry entering another survey ID.
            if (survey == null) {
                // Start the CreateSurveyActivity
                Intent intent = new Intent(AdminMenuActivity.this, ImportSurveyActivity.class);
                intent.putExtra("survey", mSurveyId);
                startActivity(intent);
            } else {
                Toast.makeText(getApplicationContext(),
                        R.string.toast_retry_enter_a_new_survey_id,
                        Toast.LENGTH_LONG).show();

            }
        }
    }

    private class GetSurveyTask extends AsyncTask<String, Integer, SurveyParcelable> {
        @Override
        protected SurveyParcelable doInBackground(String... params) {
            // Read the survey from the database that has the given survey ID
            return SurveyDataSource.getSurvey(SurveyDataSource.DATA_SOURCE,
                    getApplicationContext(),
                    params[0]); // Survey ID
        }

        @Override
        protected void onPostExecute(SurveyParcelable survey) {
            super.onPostExecute(survey);

            // If a survey was not found, display a toast to let the user know and to allow
            // them to retry entering the survey ID
            if (survey == null) {
                Toast.makeText(getApplicationContext(),
                        R.string.toast_retry_enter_survey_id,
                        Toast.LENGTH_LONG).show();
            } else {
                // Start the SurveyActivity
                Intent intent = new Intent(AdminMenuActivity.this, SurveyActivity.class);
                intent.putExtra("survey", survey);
                startActivity(intent);
            }
        }
    }

    private class GetSurveyResultsTask extends AsyncTask<String, Integer, SurveyResultsQuantified> {
        @Override
        protected SurveyResultsQuantified doInBackground(String... params) {
            // Read the survey from the database that has the given survey ID
            return SurveyDataSource.getSurveyResults(SurveyDataSource.DATA_SOURCE,
                    getApplicationContext(),
                    params[0]); // Survey ID
        }

        @Override
        protected void onPostExecute(SurveyResultsQuantified surveyResultsQuantified) {
            super.onPostExecute(surveyResultsQuantified);

            // If survey results were not found, display a toast to let the user know and to allow
            // them to retry entering the survey ID
            if (surveyResultsQuantified == null) {
                Toast.makeText(getApplicationContext(),
                        R.string.toast_retry_enter_survey_id,
                        Toast.LENGTH_LONG).show();
            } else {
                // Create the intent to start the SurveyResultsActivity
                Intent data = new Intent(AdminMenuActivity.this, SurveyResultsActivity.class);

                data.putExtra("results",surveyResultsQuantified);
                startActivity(data);
            }
        }
    }
}