package org.swe.android.activities;

import android.content.Context;
import android.net.ConnectivityManager;
import android.os.Bundle;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.view.WindowManager;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.TextView;

import org.swe.android.R;
import org.swe.android.adapters.SurveyResultsAdapter;
import org.swe.android.datasource.SurveyResultsQuantified;

import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class SurveyResultsActivity extends AppCompatActivity {

    private int mNumberofResults = 0;
    private ListView listView;
    private SurveyResultsAdapter adapter;
    List<resultsBody> l;//the list in the adapter
    private ConnectivityManager mConnectivityManager;

    private static final String QUESTION_TYPE_OVERALL = "Overall";
    private static final String QUESTION_TYPE_AGREE_DISAGREE = "Agree/Disagree";
    private static final String QUESTION_TYPE_CONFIDENCE_AND_ABILITY = "Confidence and Ability";
    private static final String QUESTION_TYPE_RECOMMEND_TO_OTHERS = "Recommend to others";
    private static final String QUESTION_TYPE_OPEN_ENDED = "Open-Ended";
    private static final String QUESTION_TYPE_GRADE = "Demographic-Grade";
    private static final String QUESTION_TYPE_GENDER = "Demographic-Gender";
    private static final String QUESTION_TYPE_RACE = "Demographic-Race";
    private static final String QUESTION_TYPE_RELATIONSHIP = "Relationship";
    private static final String QUESTION_TYPE_YESNO = "Yes/No";

    DecimalFormat twoDecimalFormat = new DecimalFormat("##.##");

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //Adjust the soft-keyboard automatically,put this line before setContentView
        getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_PAN);
        setContentView(R.layout.activity_view_survey_results);

        // Get the surveyResults extra that was sent to this activity
        final SurveyResultsQuantified  results = getIntent().getExtras().getParcelable("results");

        assert results != null;
        // Set up the action bar title using the survey ID
        ActionBar ab = getSupportActionBar();
        if (ab != null && results.getSurveyId() !=null) {
            ab.setTitle(getString(R.string.action_bar_title) + " " + results.getSurveyId());
        }
        mNumberofResults = results.getAnswersQuantified().size();
        l=new ArrayList<resultsBody>();

        //ArrayList<String> arrayList = new ArrayList<String>(Arrays.asList(array));

        int totalNumber = 0;
        Double tempPercentage;
        Double tempChoiceA;
        Double tempChoiceB;
        Double tempChoiceC;
        Double tempChoiceD;
        Double tempChoiceE;
        Double tempChoiceF;
        Double tempChoiceG;

        Double percentage;
        Double ChoiceA, ChoiceB, ChoiceC, ChoiceD, ChoiceE, ChoiceF, ChoiceG;

        for(int i=0;i<mNumberofResults;i++){
            resultsBody b=new resultsBody();
            //answersQuantified = results.getAnswersQuantified().get(i);

            //new ArrayList(survey.getQuestions().get(mCurrentQuestion).getChoices()),
            //survey.getQuestions().get(mCurrentQuestion).getExplanationRequired(),
            //survey.getQuestions().get(mCurrentQuestion).getQuestionType()
            b.question=results.getAnswersQuantified().get(i).getQuestionString();
            String questionType = results.getAnswersQuantified().get(i).getQuestionType();
            b.question_type=("Question type: " +results.getAnswersQuantified().get(i).getQuestionType());
            switch (questionType) {
                case QUESTION_TYPE_OVERALL:
                    //set up textview
                    totalNumber = results.getAnswersQuantified().get(i).getNumberOfOverall();
                  //  setUpTextView(R.id.text_choice, R.string.text_a_or_b, totalNumber);
                    // Set up the progress bar
                    tempPercentage = results.getAnswersQuantified().get(i).getaOrBTotal().doubleValue() /
                            results.getAnswersQuantified().get(i).getNumberOfOverall().doubleValue()*100;
                    percentage = Double.valueOf(twoDecimalFormat.format(tempPercentage));
                    b.text_choice = (percentage.toString() + "% of users that answered 'A' or 'B' out of " + totalNumber + " questions");

                    // setUpProgressBar(R.id.frameLayout_progress_bar, percentage);

                    break;
                case QUESTION_TYPE_AGREE_DISAGREE:

                    //set up textview
                    totalNumber = results.getAnswersQuantified().get(i).getNumberOfAgreeDisagree();


                    //setUpTextView(R.id.text_choice, R.string.text_agree_strongly_agree, totalNumber);
                    // Set up the progress bar
                    tempPercentage = results.getAnswersQuantified().get(i).getAgreeStronglyAgreeTotal().doubleValue() /
                            results.getAnswersQuantified().get(i).getNumberOfAgreeDisagree().doubleValue()*100;
                    percentage = Double.valueOf(twoDecimalFormat.format(tempPercentage));
                    b.text_choice = (percentage.toString() + "% of users that answered 'Agree' or 'Strongly Agree' out of " + totalNumber + " questions");

                   // setUpProgressBar(R.id.frameLayout_progress_bar, percentage);

                    break;
                case QUESTION_TYPE_CONFIDENCE_AND_ABILITY:
                    //set up textview
                    totalNumber = results.getAnswersQuantified().get(i).getNumberOfConfidenceAndAbility();
                    //setUpTextView(R.id.text_choice, R.string.text_improved, totalNumber);
                    // Set up the progress bar
                    tempPercentage = results.getAnswersQuantified().get(i).getImprovedTotal().doubleValue() /
                            results.getAnswersQuantified().get(i).getNumberOfConfidenceAndAbility().doubleValue()*100;
                    percentage = Double.valueOf(twoDecimalFormat.format(tempPercentage));
                    b.text_choice = (percentage.toString() + "% of users that answered 'Improved' out of " + totalNumber + " questions");

                    // setUpProgressBar(R.id.frameLayout_progress_bar, percentage);

                    break;
                case QUESTION_TYPE_RECOMMEND_TO_OTHERS:
                    //set up textview
                    totalNumber = results.getAnswersQuantified().get(i).getNumberOfRecommendToOthers();
                    //setUpTextView(R.id.text_choice, R.string.text_yes, totalNumber);
                    // Set up the progress bar
                    tempPercentage = results.getAnswersQuantified().get(i).getYesTotal().doubleValue() /
                            results.getAnswersQuantified().get(i).getNumberOfRecommendToOthers().doubleValue()*100;
                    percentage = Double.valueOf(twoDecimalFormat.format(tempPercentage));
                    b.text_choice = (percentage.toString() + "% of users that answered 'Yes' out of " + totalNumber + " questions");

                    //   setUpProgressBar(R.id.frameLayout_progress_bar, percentage);

                    break;
                case QUESTION_TYPE_GRADE:
                    //set up textview
                    totalNumber = results.getAnswersQuantified().get(i).getGradeTotal();
                    //setUpTextView(R.id.text_choice, R.string.text_yes, totalNumber);
                    // Set up the progress bar
                    tempChoiceA = results.getAnswersQuantified().get(i).getGrade3().doubleValue() /
                            results.getAnswersQuantified().get(i).getGradeTotal().doubleValue()*100;
                    tempChoiceB = results.getAnswersQuantified().get(i).getGrade4().doubleValue() /
                            results.getAnswersQuantified().get(i).getGradeTotal().doubleValue()*100;
                    tempChoiceC = results.getAnswersQuantified().get(i).getGrade5().doubleValue() /
                            results.getAnswersQuantified().get(i).getGradeTotal().doubleValue()*100;
                    tempChoiceD = results.getAnswersQuantified().get(i).getGrade6().doubleValue() /
                            results.getAnswersQuantified().get(i).getGradeTotal().doubleValue()*100;

                    ChoiceA = Double.valueOf(twoDecimalFormat.format(tempChoiceA));
                    ChoiceB = Double.valueOf(twoDecimalFormat.format(tempChoiceB));
                    ChoiceC = Double.valueOf(twoDecimalFormat.format(tempChoiceC));
                    ChoiceD = Double.valueOf(twoDecimalFormat.format(tempChoiceD));
                    b.text_choice = (ChoiceA.toString() + "% of users answered '3rd grade',\n" +
                                     ChoiceB.toString() + "% of users answered '4th grade',\n" +
                                     ChoiceC.toString() + "% of users answered '5th grade',\n" +
                                     ChoiceD.toString() + "% of users answered '6th grade'\n" +
                            " out of " + totalNumber + " questions");

                    //   setUpProgressBar(R.id.frameLayout_progress_bar, percentage);

                    break;

                case QUESTION_TYPE_GENDER:
                    //set up textview
                    totalNumber = results.getAnswersQuantified().get(i).getGenderTotal();
                    //setUpTextView(R.id.text_choice, R.string.text_yes, totalNumber);
                    // Set up the progress bar
                    tempChoiceA = results.getAnswersQuantified().get(i).getGenderFemale().doubleValue() /
                            results.getAnswersQuantified().get(i).getGenderTotal().doubleValue()*100;
                    tempChoiceB = results.getAnswersQuantified().get(i).getGenderMale().doubleValue() /
                            results.getAnswersQuantified().get(i).getGenderTotal().doubleValue()*100;

                    ChoiceA = Double.valueOf(twoDecimalFormat.format(tempChoiceA));
                    ChoiceB = Double.valueOf(twoDecimalFormat.format(tempChoiceB));
                    b.text_choice = (ChoiceA.toString() + "% of users answered 'Female',\n" +
                                     ChoiceB.toString() + "% of users answered 'Male',\n" +
                            " out of " + totalNumber + " questions");
                    //   setUpProgressBar(R.id.frameLayout_progress_bar, percentage);

                    break;

                case QUESTION_TYPE_RACE:
                    //set up textview
                    totalNumber = results.getAnswersQuantified().get(i).getRaceTotal();
                    //setUpTextView(R.id.text_choice, R.string.text_yes, totalNumber);
                    // Set up the progress bar
                    tempChoiceA = results.getAnswersQuantified().get(i).getRaceWhite().doubleValue() /
                            results.getAnswersQuantified().get(i).getRaceTotal().doubleValue()*100;
                    tempChoiceB = results.getAnswersQuantified().get(i).getRaceHispanic().doubleValue() /
                            results.getAnswersQuantified().get(i).getRaceTotal().doubleValue()*100;
                    tempChoiceC = results.getAnswersQuantified().get(i).getRaceBlack().doubleValue() /
                            results.getAnswersQuantified().get(i).getRaceTotal().doubleValue()*100;
                    tempChoiceD = results.getAnswersQuantified().get(i).getRaceAsian().doubleValue() /
                            results.getAnswersQuantified().get(i).getRaceTotal().doubleValue()*100;
                    tempChoiceE = results.getAnswersQuantified().get(i).getRaceHawaiian().doubleValue() /
                            results.getAnswersQuantified().get(i).getRaceTotal().doubleValue()*100;
                    tempChoiceF = results.getAnswersQuantified().get(i).getRaceAlaskan().doubleValue() /
                            results.getAnswersQuantified().get(i).getRaceTotal().doubleValue()*100;
                    tempChoiceG = results.getAnswersQuantified().get(i).getRaceOther().doubleValue() /
                            results.getAnswersQuantified().get(i).getRaceTotal().doubleValue()*100;

                    ChoiceA = Double.valueOf(twoDecimalFormat.format(tempChoiceA));
                    ChoiceB = Double.valueOf(twoDecimalFormat.format(tempChoiceB));
                    ChoiceC = Double.valueOf(twoDecimalFormat.format(tempChoiceC));
                    ChoiceD = Double.valueOf(twoDecimalFormat.format(tempChoiceD));
                    ChoiceE = Double.valueOf(twoDecimalFormat.format(tempChoiceE));
                    ChoiceF = Double.valueOf(twoDecimalFormat.format(tempChoiceF));
                    ChoiceG = Double.valueOf(twoDecimalFormat.format(tempChoiceG));
                    b.text_choice = (
                            ChoiceA.toString() + "% of users answered 'White or European American',\n" +
                            ChoiceB.toString() + "% of users answered 'Hispanic, Latino, or Spanish',\n" +
                            ChoiceC.toString() + "% of users answered 'Black or African-American',\n" +
                            ChoiceD.toString() + "% of users answered 'Asian American'\n" +
                            ChoiceE.toString() + "% of users answered 'Native Hawaiian or Pacific Islander',\n" +
                            ChoiceF.toString() + "% of users answered 'Native American or Alaskan Native',\n" +
                            ChoiceG.toString() + "% of users answered 'Other'\n" +
                            " out of " + totalNumber + " questions");

                    //   setUpProgressBar(R.id.frameLayout_progress_bar, percentage);

                    break;

                case QUESTION_TYPE_RELATIONSHIP:
                    //set up textview
                    totalNumber = results.getAnswersQuantified().get(i).getRelationTotal();
                    //setUpTextView(R.id.text_choice, R.string.text_yes, totalNumber);
                    // Set up the progress bar
                    tempChoiceA = results.getAnswersQuantified().get(i).getRelationMom().doubleValue() /
                            results.getAnswersQuantified().get(i).getRelationTotal().doubleValue()*100;
                    tempChoiceB = results.getAnswersQuantified().get(i).getRelationDad().doubleValue() /
                            results.getAnswersQuantified().get(i).getRelationTotal().doubleValue()*100;
                    tempChoiceC = results.getAnswersQuantified().get(i).getRelationGuardian().doubleValue() /
                            results.getAnswersQuantified().get(i).getRelationTotal().doubleValue()*100;
                    tempChoiceD = results.getAnswersQuantified().get(i).getRelationTroopLeader().doubleValue() /
                            results.getAnswersQuantified().get(i).getRelationTotal().doubleValue()*100;
                    tempChoiceE = results.getAnswersQuantified().get(i).getRelationTeacher().doubleValue() /
                            results.getAnswersQuantified().get(i).getRelationTotal().doubleValue()*100;
                    tempChoiceF = results.getAnswersQuantified().get(i).getRelationOther().doubleValue() /
                            results.getAnswersQuantified().get(i).getRelationTotal().doubleValue()*100;

                    ChoiceA = Double.valueOf(twoDecimalFormat.format(tempChoiceA));
                    ChoiceB = Double.valueOf(twoDecimalFormat.format(tempChoiceB));
                    ChoiceC = Double.valueOf(twoDecimalFormat.format(tempChoiceC));
                    ChoiceD = Double.valueOf(twoDecimalFormat.format(tempChoiceD));
                    ChoiceE = Double.valueOf(twoDecimalFormat.format(tempChoiceE));
                    ChoiceF = Double.valueOf(twoDecimalFormat.format(tempChoiceF));

                    b.text_choice = (ChoiceA.toString() + "% of users answered 'Mother',\n" +
                                    ChoiceB.toString() + "% of users answered 'Dad',\n" +
                                    ChoiceC.toString() + "% of users answered 'Guardian',\n" +
                                    ChoiceD.toString() + "% of users answered 'Troop Leader'\n" +
                                    ChoiceE.toString() + "% of users answered 'Teacher',\n" +
                                    ChoiceF.toString() + "% of users answered 'Other'\n" +
                                    " out of " + totalNumber + " questions");

                    //   setUpProgressBar(R.id.frameLayout_progress_bar, percentage);

                    break;

                case QUESTION_TYPE_YESNO:
                    //set up textview
                    totalNumber = results.getAnswersQuantified().get(i).getYesNoTotal();
                    //setUpTextView(R.id.text_choice, R.string.text_yes, totalNumber);
                    // Set up the progress bar
                    tempChoiceA = results.getAnswersQuantified().get(i).getChooseYes().doubleValue() /
                            results.getAnswersQuantified().get(i).getYesNoTotal().doubleValue()*100;
                    tempChoiceB = results.getAnswersQuantified().get(i).getChooseNo().doubleValue() /
                            results.getAnswersQuantified().get(i).getYesNoTotal().doubleValue()*100;

                    ChoiceA = Double.valueOf(twoDecimalFormat.format(tempChoiceA));
                    ChoiceB = Double.valueOf(twoDecimalFormat.format(tempChoiceB));
                    b.text_choice = (ChoiceA.toString() + "% of users answered 'Yes',\n" +
                            ChoiceB.toString() + "% of users answered 'No',\n" +
                            " out of " + totalNumber + " questions");
                    //   setUpProgressBar(R.id.frameLayout_progress_bar, percentage);

                    break;
                /*
                case QUESTION_TYPE_OPEN_ENDED:

                    LinearLayout ll = (LinearLayout) findViewById(R.id.ll_open_ended_questions);

                    LayoutInflater inflater = (LayoutInflater)getSystemService(Context.LAYOUT_INFLATER_SERVICE);

                    Iterator iterator = results.getAnswersQuantified().get(i).getOpenEndedQuestions().entrySet().iterator();
                    //openEndedQuestions.entrySet().iterator();
                    while (iterator.hasNext()) {
                        View view = inflater.inflate(R.layout.text_bold, ll, false);
                        Map.Entry pair = (Map.Entry) iterator.next();

                        TextView text = (TextView) view.findViewById(R.id.text);
                        text.setText(pair.getKey().toString());

                        // Add the view to the list
                        ll.addView(view);

                        for (String s : results.getAnswersQuantified().get(i).getOpenEndedQuestions().get(pair.getKey().toString())) {
                            view = inflater.inflate(R.layout.text_regular, ll, false);

                            // Create the view that contains the question and its answer
                            text = (TextView) view.findViewById(R.id.text);
                            text.setText("- " + s);

                            // Add the view to the list
                            ll.addView(view);
                        }
                        iterator.remove(); // avoids a ConcurrentModificationException
                    }

                    break;

                */
                default:
                    break;

            }
            l.add(b);
        }
        listView = (ListView) findViewById(R.id.listView_results);


        adapter = new SurveyResultsAdapter(SurveyResultsActivity.this, l);

        listView.setAdapter(adapter);
        // Set up the Connectivity Manager
        mConnectivityManager = (ConnectivityManager) getApplicationContext().
                getSystemService(Context.CONNECTIVITY_SERVICE);

        /*
        // Set up Take Survey button
        final Button pdfButton = (Button) findViewById(R.id.button_generate_pdf_file);



        pdfButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // If the user does not have an internet connection, let them know that one
                // is required to look up the survey
                if (!NetworkHelper.hasInternetConnection(mConnectivityManager)) {
                    Toast.makeText(getApplicationContext(),
                            R.string.toast_internet_connection_required,
                            Toast.LENGTH_LONG).show();
                } else {
                    // Create a object of PdfDocument
                    PdfDocument document = new PdfDocument();

                    // content view is EditText for my case in which user enters pdf content
                    View content = findViewById(R.id.listView_results);

                    // crate a page info with attributes as below
                    // page number, height and width
                    // i have used height and width to that of pdf content view
                    int pageNumber = 1;
                    PageInfo pageInfo = new PageInfo.Builder(content.getWidth(),
                            content.getHeight() - 20, pageNumber).create();

                    // create a new page from the PageInfo
                    Page page = document.startPage(pageInfo);

                    // repaint the user's text into the page
                    content.draw(page.getCanvas());

                    // do final processing of the page
                    document.finishPage(page);

                    // saving pdf document to sdcard
                    SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddhhmmss");
                    String pdfName = "pdfdemo"
                            + sdf.format(Calendar.getInstance().getTime()) + ".pdf";

                    // all created files will be saved at path /sdcard/PDFDemo_AndroidSRC/
                    //File outputFile = new File("/sdcard/PDFDemo_AndroidSRC/", pdfName);
                    File outputFile = new File(getFilesDir(), pdfName);

                    try {
                        outputFile.createNewFile();
                        OutputStream out = new FileOutputStream(outputFile);
                        document.writeTo(out);
                        //++++++++++++
                        Intent shareIntent = new Intent(Intent.ACTION_SEND);
                        shareIntent.setType("application/pdf");
                        shareIntent.putExtra(Intent.EXTRA_EMAIL, new String[] { "liyongji89@gmail.com" });
                        shareIntent.putExtra(Intent.EXTRA_SUBJECT, "test ");
                        shareIntent.putExtra(Intent.EXTRA_TEXT, "test");
                        //shareIntent.putExtra(Intent.EXTRA_STREAM, Uri.parse("file:///MyAPP/" + "test.pdf"));
                        shareIntent.putExtra(Intent.EXTRA_STREAM, Uri.parse(pdfName));
                        startActivity(Intent.createChooser(shareIntent, "Send mail..."));
                        finish();

                        //++++++++++
                        document.close();
                        out.close();
                        Toast.makeText(getApplicationContext(),pdfName,
                                //R.string.toast_internet_connection_required,
                                Toast.LENGTH_LONG).show();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
            }
        });

        */

    }

    private void setUpTextView(int tvResourceId, int stringResourceId, int numberOfQuestions) {
        TextView tv = (TextView) findViewById(tvResourceId);
        tv.setText(String.format(getResources().getString(stringResourceId), numberOfQuestions));
    }


    private void setUpProgressBar(int resourceId, Double percentage) {
        ProgressBar pb = (ProgressBar) findViewById(resourceId).findViewById(R.id.progress_bar);
        TextView tvPercentage = (TextView) findViewById(resourceId).findViewById(R.id.percentage);
        pb.setProgress(percentage.intValue());
        tvPercentage.setText(percentage.toString() + "%");
    }

    public class resultsBody{//to restore the class in the adapter
        public String question;
        public String question_type;
        public String text_choice;
        public HashMap openEndedQuestions;
        ProgressBar pb;

        public String getQuestion() {
            return question;
        }
        public void setQuestion(String question) {
            this.question = question;
        }
        public String getQuestiontype() {
            return question_type;
        }
        public void setQuestiontype(String questiontype) {
            this.question_type = questiontype;
        }
    }
}
