package org.swe.android.datasource;

/**
 * Created by YongjiLi on 2/1/16.
 */
public class TemplateListItem {
    String templateId;
    String templateIntroduction;

    public String getTemplateId() {
        return templateId;
    }
    public void setTemplateId(String templateId) {
        this.templateId = templateId;
    }
    public String getTemplateIntroduction() {
        return templateIntroduction;
    }
    public void setTemplateIntroduction(String templateIntroduction) {
        this.templateIntroduction = templateIntroduction;
    }
}
